"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Field, Notice } from "./UI";
import { useFeedback } from "./FeedbackProvider";
import { createClient } from "@/lib/supabase/client";
import { rpc } from "@/lib/api";
import { errorMessage, fileError, money } from "@/lib/domain";
import { calculateAllocation, initialSelection, automaticReceiptAllocation, editableReceiptSelection, type ReceiptExtraction, type ReceiptSelection, type ReceiptPlan, type ReceiptAssistantValue } from "@/lib/ai/receipt-allocation";
import styles from "./ReceiptAssistant.module.css";
type Duplicates = { other_matches: number; own_matches: { claim_id: string; code: string; status: string }[] };
export default function ReceiptAssistant({ activityId, initialPlan, onChange, onBusyChange, onFileChange, existingReceiptCount = 0, existingAttachmentCount = 0 }: {
  activityId: string; initialPlan: ReceiptPlan | null;
  onChange: (value: ReceiptAssistantValue | null) => void;
  onBusyChange: (busy: boolean) => void;
  onFileChange?: (file: File | null) => void;
  existingReceiptCount?: number;
  existingAttachmentCount?: number;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  const [previewFailed, setPreviewFailed] = useState(false);
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState({ title: "Reading receipt…", description: "" });
  const progressTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const [error, setError] = useState("");
  const [sessionId, setSessionId] = useState(initialPlan?.session_id ?? "");
  const [reading, setReading] = useState<ReceiptExtraction | null>(initialPlan?.extraction ?? null);
  const [selection, setSelection] = useState<ReceiptSelection | null>(initialPlan ? editableReceiptSelection(initialPlan.extraction, initialPlan.selection) : null);
  const [duplicates, setDuplicates] = useState<Duplicates | null>(null);
  const notify = useFeedback();
  useEffect(() => () => clearTimeout(progressTimer.current), []);
  useEffect(() => {
    return () => { if (preview) URL.revokeObjectURL(preview); };
  }, [preview]);
  function change(next: ReceiptSelection) {
    setSelection(next);
    if (reading && sessionId) onChange({ sessionId, extraction: reading, selection: next });
  }
  function choose(next: File | null) {
    if (!next || busy) return;
    const issue = fileError(next) || (next.name.length > 200 ? "Rename the receipt to at most 200 characters." : null);
    if (issue) { setError(issue); return; }
    setFile(next); onFileChange?.(next); setPreview(URL.createObjectURL(next)); setPreviewFailed(false); setReading(null); setSelection(null); setSessionId(""); setDuplicates(null); setError(""); onChange(null);
  }
  async function read() {
    if (busy || !file || !consent) return;
    setBusy(true); onBusyChange(true); setError("");
    function reportProgress(title: string, description: string) {
      clearTimeout(progressTimer.current);
      setProgress({ title, description });
      notify({ title, description, tone: "progress" });
      progressTimer.current = setTimeout(() => {
        const waiting = "Still working—this may take a moment. Keep this page open.";
        setProgress({ title, description: waiting });
        notify({ title, description: waiting, tone: "progress" });
      }, 20000);
    }
    try {
      let sid = sessionId;
      if (!sid) {
        reportProgress("Uploading receipt…", "Uploading your receipt privately. Keep this page open.");
        const draft = await rpc<{ id: string; path: string }>("ml_create_receipt_draft", { p_activity_id: activityId, p_name: file.name, p_mime: file.type });
        const upload = await createClient().storage.from("receipt-drafts").upload(draft.path, file, { contentType: file.type, upsert: false });
        if (upload.error) throw new Error("Receipt upload failed. Check your connection and migration 013, then retry.");
        sid = draft.id; setSessionId(sid);
      }
      reportProgress("Reading receipt…", "Extracting receipt details and checking for duplicates. Keep this page open.");
      const response = await fetch(`/api/receipt-drafts/${sid}/extract`, { method: "POST", headers: { "x-moneylai-ai-consent": "yes" }, signal: AbortSignal.timeout(115000) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Could not read the receipt.");
      const extracted = result.extraction as ReceiptExtraction;
      const next = initialSelection(extracted);
      setReading(extracted); setSelection(next); setDuplicates(result.duplicates);
      onChange({ sessionId: sid, extraction: extracted, selection: next });
      notify({ title: "Receipt ready", description: "Choose full receipt or selected items, check the total, then continue." });
      requestAnimationFrame(() => { const result = document.getElementById("assistant-results"); result?.focus(); result?.scrollIntoView({ block: "start", behavior: "smooth" }); });
    } catch (e) {
      const message = e && typeof e === "object" && "code" in e && ["PGRST202", "42P01"].includes(String(e.code))
        ? "Receipt assistance needs migration 013 in Supabase. You can continue with manual entry."
        : e instanceof Error && e.name === "TimeoutError" ? "Reading took too long. Retry to retrieve any completed reading, or use manual entry." : errorMessage(e);
      setError(message); notify({ title: "Receipt could not be read", description: message, tone: "error" });
    } finally { clearTimeout(progressTimer.current); setBusy(false); onBusyChange(false); }
  }
  let calculation = null, issue = "", automaticIssue = "";
  let automatic = null;
  if (reading && selection?.mode === "simple") {
    try { automatic = automaticReceiptAllocation(reading, selection); } catch { automaticIssue = "AI could not verify the item breakdown or adjustments. Check the original and use Change reimbursement amount to confirm your amount with a reason."; }
  }
  if (reading && selection) {
    try { calculation = calculateAllocation(reading, { ...selection, confirmed: true }); } catch (e) { issue = errorMessage(e); }
  }
  return <section className={styles.assistant} aria-label="Receipt drafting assistant" aria-busy={busy}>
    <div className={styles.workspace}>
      <div>
        <div className={styles.drop} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); choose(e.dataTransfer.files[0] ?? null); }}>
          <label htmlFor="assistant-file"><strong>{file?.name ?? initialPlan?.original_name ?? (existingReceiptCount ? "Add another receipt" : "Choose or drop a receipt")}</strong></label>
          <input id="assistant-file" type="file" accept="image/jpeg,image/png,application/pdf" disabled={busy || existingAttachmentCount >= 5 || Boolean(initialPlan && existingReceiptCount)} onChange={e => choose(e.target.files?.[0] ?? null)} />
          <small>JPG, PNG or PDF · max 5 MB each</small>
          {initialPlan && existingReceiptCount > 0 && <small>To replace this receipt, remove it above first.</small>}
          {existingAttachmentCount >= 5 && <small>Five files already attached. Remove a file before adding another.</small>}
        </div>
        {preview && !previewFailed && <details className={styles.disclosure}><summary>Preview receipt</summary>{file?.type === "application/pdf" ? <iframe src={preview} title="Original receipt preview" className={styles.preview} />
          // Local user-selected preview; no image optimization or remote image request is needed.
          // eslint-disable-next-line @next/next/no-img-element
          : <img src={preview} alt="Original receipt selected for extraction" className={styles.preview} onError={() => setPreviewFailed(true)} />}</details>}
        {previewFailed && <Notice>The image preview is unavailable. Check that the file is a valid image, or choose another receipt.</Notice>}
        <details className={styles.disclosure}><summary>Fill details with AI <span>Optional</span></summary>
        <label className={styles.check}><input type="checkbox" checked={consent} disabled={busy} onChange={e => setConsent(e.target.checked)} />Send this receipt and selected activity context to Google Gemini. Bank details are excluded.</label>
        <button type="button" className={`button secondary ${busy ? styles.busyButton : ""}`} aria-busy={busy} disabled={busy || !file || !consent || existingReceiptCount > 0} onClick={read}>{busy ? <><span className="loading-spinner loading-spinner-small" aria-hidden="true" />{progress.title}</> : error ? "Retry reading receipt" : "Read receipt with AI"}</button>
        {existingReceiptCount > 0 && <small>AI item selection uses one receipt. Review the saved selection below, or continue manually.</small>}
        {busy && <p role="status">{progress.description}</p>}
        <details className={styles.disclosure}><summary>Upload privacy & retention</summary><small>Temporary AI uploads expire for use after 24 hours. Abandoned uploads are cleaned on your next extraction. Saved originals stay with the claim.</small></details>
        </details>
      </div>
      <div>
        {error && <Notice tone="error">{error}</Notice>}
        {duplicates && (duplicates.other_matches > 0 || duplicates.own_matches.length > 0) && <Notice>
          <strong>Possible duplicate receipt — review before submitting.</strong>
          {duplicates.other_matches > 0 && <p>A match exists in another member’s claim. Treasurer can check the originals; private claim details are hidden.</p>}
          {duplicates.own_matches.map(m => <p key={m.claim_id}><Link href={`/claims/${m.claim_id}`}>Your claim {m.code} · {m.status}</Link></p>)}
          <small>Treasurer will verify the originals.</small>
        </Notice>}
        {reading && selection && <>
          <div className={styles.facts} id="assistant-results" tabIndex={-1}><strong>{reading.merchant ?? "Merchant unclear"}</strong><span>{reading.currency ?? "Currency unclear"} {reading.total ?? "Total unclear"} · {reading.date ?? "Date unclear"}</span><small>{reading.document_type.replaceAll("_", " ")} · payment {reading.payment_status}{reading.receipt_number ? ` · ${reading.receipt_number}` : ""}</small></div>
          {(!reading.readable || reading.document_type !== "receipt" || reading.payment_status !== "paid") && <Notice>Evidence needs review: {reading.document_type.replaceAll("_", " ")}, payment {reading.payment_status}, {reading.readable ? "readable" : "not reliably readable"}. Confirm payment evidence; this is not a finding of fraud.</Notice>}
          {reading.warnings.map((w, i) => <Notice key={i}>{w}</Notice>)}
          <fieldset className={styles.scope}><legend>What are you claiming?</legend>
            <label><input type="radio" name="receipt-scope" checked={selection.mode === "full"} onChange={() => change(initialSelection(reading))} /><span>Full receipt — all purchases are for this activity</span></label>
            <label><input type="radio" name="receipt-scope" checked={selection.mode !== "full"} onChange={() => change(initialSelection(reading, "simple"))} /><span>Selected items only</span></label>
          </fieldset>
          {selection.mode === "full" ? <>
            <Field label="Final paid receipt total (RM)" id="full-receipt-total"><input id="full-receipt-total" inputMode="decimal" value={selection.receipt_total} onChange={e => change({ ...selection, receipt_total: e.target.value, confirmed: false })} /></Field>
            <p>Use Grand Total. Charges and discounts are already included; nothing is added again.</p>
            {reading.total === null && <Notice>AI could not read the total. Enter it from the original.</Notice>}
            {reading.items.some(i => i.relevance === "needs_confirmation") && <Notice>Check the activity purpose of: {reading.items.filter(i => i.relevance === "needs_confirmation").map(i => i.description).join(", ")}. Choose selected items if any purchase is personal.</Notice>}
            {reading.total !== null && Number(reading.total) !== Number(selection.receipt_total) && <Field label="Why did you correct the AI total?" id="full-correction"><textarea id="full-correction" rows={2} maxLength={1000} value={selection.correction_reason} onChange={e => change({ ...selection, correction_reason: e.target.value, confirmed: false })} /></Field>}
          </> : <>
          <p><b>Select the activity purchases.</b> Uncheck personal items.</p>
          <div className={styles.items}>{reading.items.map((item, index) => {
            const row = selection.items[index];
            const update = (patch: Partial<typeof row>) => change({ ...selection, confirmed: false, items: selection.items.map((r, i) => i === index ? { ...r, ...patch } : r) });
            return <article className={styles.item} key={item.id}>
              <label className={styles.check}><input type="checkbox" checked={row.included} onChange={e => { const included = e.target.checked; change({ ...selection, confirmed: false, mode: selection.mode, items: selection.items.map((r, i) => i === index ? { ...r, included, reason: !included && !r.reason ? "Not claimed / personal purchase" : r.reason } : r) }); }} /><strong>{item.description}</strong></label>
              {item.relevance === "needs_confirmation" && <p className={styles.flag}>Confirm activity purpose: {item.reason}</p>}
              <strong>{row.amount ? money(row.amount) : "Amount unclear"}</strong>
              {(item.relevance === "needs_confirmation" || !row.included || row.reason) && <Field label={row.included ? "Activity purpose / note" : "Why is this item excluded?"} id={`line-reason-${index}`}><input id={`line-reason-${index}`} maxLength={1000} value={row.reason} onChange={e => update({ reason: e.target.value })} /></Field>}
            </article>;
          })}</div>
          <p>Selected share · {(() => {
            if (selection.items.some(i => !i.amount)) return "Item amounts unclear";
            const all = selection.items.reduce((n, i) => n + Number(i.amount), 0);
            const selected = selection.items.filter(i => i.included).reduce((n, i) => n + Number(i.amount), 0);
            return all ? `${money(selected)} / ${money(all)} · ${(selected / all * 100).toFixed(1)}%` : "Check the original";
          })()}</p>
          {automaticIssue && <Notice>{automaticIssue}</Notice>}
          {automatic && <div className={styles.facts}>
            <strong>Automatic reimbursement: {money(automatic.expected_amount)}</strong>
            {(["tax", "discount", "rounding"] as const).filter(k => Number(automatic[k]) !== 0).map(k => <span key={k}>Receipt {k} {money(reading[k])} × selected share = {money(automatic[k])}{k === "discount" ? " deducted" : ""}</span>)}
            {(["tax", "discount", "rounding"] as const).every(k => Number(automatic[k]) === 0) && <small>No extra adjustments applied. Included amounts are not counted twice.</small>}
          </div>}
          <details className={styles.disclosure}><summary>Check receipt total</summary>
            <Field label="Final paid receipt total (RM)" id="confirmed-receipt-total"><input id="confirmed-receipt-total" inputMode="decimal" value={selection.receipt_total} onChange={e => change({ ...selection, confirmed: false, receipt_total: e.target.value })} /></Field>
            {(reading.total === null || Number(reading.total) !== Number(selection.receipt_total)) && <Field label="Why did you enter or correct the receipt total?" id="correction-reason"><textarea id="correction-reason" rows={2} maxLength={1000} value={selection.correction_reason} onChange={e => change({ ...selection, confirmed: false, correction_reason: e.target.value })} /></Field>}
          </details>
          <button type="button" className="text-button" onClick={() => change({ ...selection, confirmed: false, claimed_amount: selection.claimed_amount === undefined ? automatic?.expected_amount ?? "" : undefined, override_reason: "" })}>{selection.claimed_amount === undefined ? "Change reimbursement amount" : "Use automatic amount"}</button>
          {selection.claimed_amount !== undefined && <>
            <Notice>This is your confirmed amount, not an AI-verified calculation. Treasurer will see the original calculation and your reason.</Notice>
            <Field label="This reimbursement amount (RM)" id="reimbursement-amount"><input id="reimbursement-amount" inputMode="decimal" value={selection.claimed_amount} onChange={e => change({ ...selection, confirmed: false, claimed_amount: e.target.value })} /></Field>
            <Field label="Why did you change or manually confirm this amount?" id="override-reason"><textarea id="override-reason" rows={2} maxLength={1000} value={selection.override_reason ?? ""} onChange={e => change({ ...selection, confirmed: false, override_reason: e.target.value })} /></Field>
          </>}
          </>}
          {issue && <Notice>{issue}</Notice>}
          {calculation && <div className={styles.total}><small>{selection.claimed_amount !== undefined ? "Member-confirmed reimbursement" : "Reimbursement"}</small><strong>{money(calculation.expected_amount)}</strong>{selection.mode === "full" ? <small>Final paid total · no separate allocation</small> : calculation.automatic_issue ? <small>Automatic allocation is unavailable. This amount was confirmed by the member; Treasurer must verify it.</small> : <><span>Items {money(calculation.selected_subtotal)}{Number(calculation.tax) !== 0 && ` + extra tax ${money(calculation.tax)}`}{Number(calculation.discount) !== 0 && ` − extra discount ${money(calculation.discount)}`}{Number(calculation.rounding) !== 0 && ` + rounding ${money(calculation.rounding)}`}</span><small>Included charges and discounts are not applied twice. Excluded items: {money(calculation.excluded_subtotal)}</small></>}</div>}
          <label className={styles.check}><input id="assistant-confirm" type="checkbox" checked={selection.confirmed} onChange={e => change({ ...selection, confirmed: e.target.checked })} />{selection.mode === "full" ? "I checked the final paid total and all purchases are for this activity." : "I checked the selected purchases and reimbursement amount."}</label>
          <p><button type="button" className="text-button" onClick={() => { setReading(null); setSelection(null); onChange(null); notify({ title: "Manual entry selected", description: "Choose Next to enter your expense details. Your selected receipt is kept." }); }}>Enter details myself instead</button></p>
        </>}
      </div>
    </div>
  </section>;
}
